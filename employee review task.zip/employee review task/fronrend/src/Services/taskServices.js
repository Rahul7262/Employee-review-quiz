
// import axios from 'axios';

// const USER_REST_URL = 'http://localhost:1234/getemp/7'
// const USER_REST_URL_CREATE ='http://localhost:1234/signUp'
// class Service {
//     getUser(){
//        return axios.get(USER_REST_URL);
//     }

//     createUser(user){
//         return axios.post(USER_REST_URL_CREATE,user);
//     }

// }
// export default new Service();