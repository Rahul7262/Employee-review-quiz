import React ,{useState, useEffect} from 'react';
import { Link, useNavigate } from "react-router-dom";
import axios from 'axios';


const Users = () => {

    const [emp, setEmp] = useState([]);

    useEffect(() => {
        const loademp = async () => {
          const result2 = await axios.get(`http://localhost:1234/getemp/{12}`);
          setEmp(result2.data);
          console.log(emp)
        }
        loademp();
      }, []);



    const [data, setData] = useState({});
    const { first, second, third,fourth,fifth } = data;
    const onInputChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
    };
    
    const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:1234/signUp', data);
    };


    return (
        <div className="container " id="box">
            <form action="" className="mt-3" onSubmit={(e) => onSubmit(e)} >
                <div class=" row">
                    <div class="col-md-9 w-50 " >
                        <label for=" ">1. How do you feel as a employee in orginaization.</label>
                    </div>
                    <div class="col-md-3" id="first">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e.target.value)} id="first" >

                            <option value="5">excellent</option>
                            <option value="4" >very good</option>
                            <option value="3">good</option>
                            <option value="2" >poor</option>
                            <option value="1" >bad</option>
                        </select>
                    </div>
                </div>
                <div class=" row mt-2">
                    <div class="col-md-9 w-50 " >
                        <label for=" ">2. How do you feel with your teammates.</label>
                    </div>
                    <div class="col-md-3" id="first">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="second" >

                            <option value="5">excellent</option>
                            <option value="4" >very good</option>
                            <option value="3">good</option>
                            <option value="2" >poor</option>
                            <option value="1" >bad</option>
                        </select>
                    </div>
                </div>
                <div class=" row mt-2">
                    <div class="col-md-9 w-50" >
                        <label for=" ">3. How do you feel with culture of your office</label>
                    </div>
                    <div class="col-md-3" id="first">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="third" >

                            <option value="5">excellent</option>
                            <option value="4" >very good</option>
                            <option value="3">good</option>
                            <option value="2" >poor</option>
                            <option value="1" >bad</option>
                        </select>
                    </div>
                </div>
                <div class=" row mt-2">
                    <div class="col-md-9 w-50" >
                        <label for=" ">4. How do you feel  about   your meeting with technical manager.</label>
                    </div>
                    <div class="col-md-3" id="first">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="fourth">

                            <option value="5">excellent</option>
                            <option value="4" >very good</option>
                            <option value="3">good</option>
                            <option value="2" >poor</option>
                            <option value="1" >bad</option>
                        </select>
                    </div>
                </div>
                <div class=" row mt-2">
                    <div class="col-md-9 w-50" >
                        <label for=" ">5. How do you feel as a employee in orginaization.</label>
                    </div>
                    <div class="col-md-3" id="first">
                        <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="fifth" >

                            <option value="5">excellent</option>
                            <option value="4" >very good</option>
                            <option value="3">good</option>
                            <option value="2" >poor</option>
                            <option value="1" >bad</option>
                        </select>
                    </div>
                </div>
                <div class="d-grid gap-2 col-2 mx-auto mb-2 mt-3">
                    <button class="btn btn-success" type="submit">Submit</button>
                    
                </div>
            </form>
        </div>
    );
}

export default Users;
