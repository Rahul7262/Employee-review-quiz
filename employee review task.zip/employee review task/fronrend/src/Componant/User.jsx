// import React, { useState } from "react";
// import { Link, useNavigate } from "react-router-dom";



// export default function user() {

//    let navigate = useNavigate();
    
//    const [user, setUser] = useState({
//     first: "",
//     second: "",
//     third: "",
//     fourth: "",
//     fifth: "",
//   });
    
//     const { first, second, third,fourth,fifth } = user;


//     const onSubmit = async (e) => {
//         e.preventDefault();
//         await axios.post("http://localhost:8080/user", user);
//         navigate("/");
//     };




//     return (
//         <div className="container " id="box">
//             <form action="" className="mt-3" >
//                 <div class=" row">
//                     <div class="col-md-9 w-50 bg-light" >
//                         <label for=" ">1. How do you feel as a employee in orginaization.</label>
//                     </div>
//                     <div class="col-md-3" id="first">
//                         <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="first" value={data.first}>

//                             <option value={5}>excellent</option>
//                             <option value={4} >very good</option>
//                             <option value={3}>good</option>
//                             <option value={2} >poor</option>
//                             <option value={1} >bad</option>
//                         </select>
//                     </div>
//                 </div>
//                 <div class=" row mt-2">
//                     <div class="col-md-9 w-50 " >
//                         <label for=" ">2. How do you feel with your teammates.</label>
//                     </div>
//                     <div class="col-md-3" id="first">
//                         <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="second" value={data.second}>

//                             <option value={5}>excellent</option>
//                             <option value={4} >very good</option>
//                             <option value={3}>good</option>
//                             <option value={2} >poor</option>
//                             <option value={1} >bad</option>
//                         </select>
//                     </div>
//                 </div>
//                 <div class=" row mt-2">
//                     <div class="col-md-9 w-50" >
//                         <label for=" ">3. How do you feel with culture of your office</label>
//                     </div>
//                     <div class="col-md-3" id="first">
//                         <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="third" value={data.third}>

//                             <option value={5}>excellent</option>
//                             <option value={4} >very good</option>
//                             <option value={3}>good</option>
//                             <option value={2} >poor</option>
//                             <option value={1} >bad</option>
//                         </select>
//                     </div>
//                 </div>
//                 <div class=" row mt-2">
//                     <div class="col-md-9 w-50" >
//                         <label for=" ">4. How do you feel  about   your meeting with technical manager.</label>
//                     </div>
//                     <div class="col-md-3" id="first">
//                         <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="fourth" value={data.fourth}>

//                             <option value={5}>excellent</option>
//                             <option value={4} >very good</option>
//                             <option value={3}>good</option>
//                             <option value={2} >poor</option>
//                             <option value={1} >bad</option>
//                         </select>
//                     </div>
//                 </div>
//                 <div class=" row mt-2">
//                     <div class="col-md-9 w-50" >
//                         <label for=" ">5. How do you feel as a employee in orginaization.</label>
//                     </div>
//                     <div class="col-md-3" id="first">
//                         <select class="form-select form-select-sm" aria-label=".form-select-sm example" onChange={(e) => onInputChange(e)} id="fifth" value={data.fifth}>

//                             <option value={5}>excellent</option>
//                             <option value={4} >very good</option>
//                             <option value={3}>good</option>
//                             <option value={2} >poor</option>
//                             <option value={1} >bad</option>
//                         </select>
//                     </div>
//                 </div>
//                 <div class="d-grid gap-2 col-2 mx-auto mb-2 mt-3">
//                     <button class="btn btn-success" type="button">Submit</button>
//                 </div>
//             </form>
//         </div>
//     )
// }