import React from 'react'

export default function result() {
  return (
    <div className='container'>
      <div className='row'>
        <div className='b-rounded w-50 bg-info'>
             <h2>happy</h2>
        </div>

      </div>


    </div>
  )
}
