package com.spring.task.Dao;

import java.util.List;
import java.util.Optional;

import com.spring.task.modal.Task;

public interface TaskDao {

	Task signUp(Task task);

	List<Task> getallEmp();

	Optional<Task> getEmp(Long id);

}
