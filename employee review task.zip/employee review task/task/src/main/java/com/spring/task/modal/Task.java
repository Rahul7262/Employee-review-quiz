package com.spring.task.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TASK")
public class Task {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column 
	private long first;
	@Column
	private long second;
	@Column
	private long third;
	@Column
	private long fourth;
	@Column
	private long fifth;



	public Task(long first, long second, long third, long fourth, long fifth) {
		super();
		
		this.first = first;
		this.second = second;
		this.third = third;
		this.fourth = fourth;
		this.fifth = fifth;
	}
	public Task() {
		
		// TODO Auto-generated constructor stub
	}
	
	
	public long getFirst() {
		return first;
	}
	public void setFirst(long first) {
		this.first = first;
	}
	public long getSecond() {
		return second;
	}
	public void setSecond(long second) {
		this.second = second;
	}
	public long getThird() {
		return third;
	}
	public void setThird(long third) {
		this.third = third;
	}
	public long getFourth() {
		return fourth;
	}
	public void setFourth(long fourth) {
		this.fourth = fourth;
	}
	public long getFifth() {
		return fifth;
	}
	public void setFifth(long fifth) {
		this.fifth = fifth;
	}


}
