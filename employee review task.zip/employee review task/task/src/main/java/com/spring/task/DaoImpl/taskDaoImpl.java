package com.spring.task.DaoImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.task.Dao.TaskDao;
import com.spring.task.modal.Task;
import com.spring.task.repository.TaskRepository;

@Repository
public class taskDaoImpl implements TaskDao {

	@Autowired
	TaskRepository TRepo;
	
	@Override
	public Task signUp(Task task) {
		// TODO Auto-generated method stub
		return TRepo.save(task);
	}

	@Override
	public List<Task> getallEmp() {
		// TODO Auto-generated method stub
		return TRepo.findAll();
	}

	@Override
	public Optional<Task> getEmp(Long id) {
		// TODO Auto-generated method stub
		return TRepo.findById(id);
	}
	

}
