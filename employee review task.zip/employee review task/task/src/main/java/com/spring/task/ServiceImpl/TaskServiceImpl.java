package com.spring.task.ServiceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.spring.task.Dao.TaskDao;
import com.spring.task.Service.TaskService;
import com.spring.task.modal.Task;


@Service
public class TaskServiceImpl implements TaskService{
   
	@Autowired
	TaskDao TDao;

	@Override
	public Task signUp(Task task) {
		// TODO Auto-generated method stub
		return TDao.signUp(task);
	}

	@Override
	public List<Task> getallEmp() {
		// TODO Auto-generated method stub
		return TDao.getallEmp();
	}

	@Override
	public Optional<Task> getEmp(Long id) {
		// TODO Auto-generated method stub
		return TDao.getEmp(id);
	}
	
	
}
