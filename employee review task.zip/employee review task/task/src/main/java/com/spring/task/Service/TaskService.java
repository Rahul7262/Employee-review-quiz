package com.spring.task.Service;

import java.util.List;
import java.util.Optional;

import com.spring.task.modal.Task;

public interface TaskService {

	public Task signUp(Task task);

	public List<Task> getallEmp();

	public Optional<Task> getEmp(Long id);

}
